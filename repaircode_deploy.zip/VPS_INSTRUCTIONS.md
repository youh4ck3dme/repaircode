# Deploying repaircode on your VPS

Since your domain `nexify-studio.tech` points to your remote VPS (`199.36.158.100`), you must run the deployment there for the SSL certificate to be issued correctly.

## 1. Upload the Deployment Package
Open a terminal on your Mac (or local machine) and upload the `repaircode_deploy.zip` file to your server. 
Replace `root` with your username if differnet.

```bash
scp repaircode_deploy.zip root@199.36.158.100:~/
```

## 2. Connect to the Server
SSH into your VPS:

```bash
ssh root@199.36.158.100
```

## 3. Prepare and Run
Once logged in, run the following commands one by one:

```bash
# 1. Update system
apt update && apt upgrade -y

# 2. Install Unzip and Docker (if not already installed)
apt install -y unzip curl
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | sh
fi

# 3. Unzip the package
unzip repaircode_deploy.zip -d repaircode
cd repaircode

# 4. Make script executable and run
chmod +x deploy.sh
./deploy.sh
```

## 4. Done!
The script will:
1. Start Nginx on port 80.
2. Obtain the SSL certificate from Let's Encrypt.
3. Reload Nginx with secure HTTPS configuration.

Your site will then be live at **https://nexify-studio.tech**.
